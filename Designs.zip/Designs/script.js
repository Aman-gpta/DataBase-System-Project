let API_URL = "http://localhost:4000/";
let myfunction = async(event) =>{   
    event.preventDefault();
let usernamee = document.getElementById("user2");
let emaill = document.getElementById("email2");
let pass = document.getElementById("password2");
usernamee = usernamee.value;
emaill = emaill.value;
pass = pass.value;
console.log(emaill);
const data = {
    username: usernamee,
    email : emaill,
    password: pass
}
console.log(JSON.stringify(data));
localStorage.setItem("username", data.username);
        const response = await fetch(API_URL+"UserData",{
    method: 'POST',
    body: JSON.stringify(data),
    headers: { 'Content-Type': 'application/json' }
});
window.location.reload();
         }  ;
const wrapper=document.querySelector('.wrapper');
const loginLink=document.querySelector('.login-link');
const registerLink=document.querySelector('.register-link');


registerLink.addEventListener('click',()=>{
    wrapper.classList.add('active');
})
loginLink.addEventListener('click',()=>{
    wrapper.classList.remove('active');
})
