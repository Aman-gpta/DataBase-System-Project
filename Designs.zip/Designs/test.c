#include <stdio.h>

int main() {
    char s[10];
    printf("Enter your name: ");
    scanf("%s", s);
    printf("Hello %s", s);
    
}